## 说明
使用json-server请查看[文档](https://github.com/typicode/json-server)  
使用默认端口3000即可

## 使用指南（对应D组版）
在当前目录下打开cmd，输入以下命令
```
$ npm install json-server --save-dev
```
安装成功后
```
$ node server.js
```