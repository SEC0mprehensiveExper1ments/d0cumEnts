export default {
  'component.tagSelect.expand': '展開',
  'component.tagSelect.collapse': '折りたたむ',
  'component.tagSelect.all': 'すべて',
};
