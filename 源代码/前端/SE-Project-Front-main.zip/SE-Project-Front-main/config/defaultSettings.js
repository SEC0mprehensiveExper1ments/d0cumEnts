const Settings = {
  navTheme: 'light',
  // 拂晓蓝
  primaryColor: '#1890ff',
  layout: 'mix',
  contentWidth: 'Fluid',
  fixedHeader: false,
  fixSiderbar: true,
  colorWeak: false,
  title: '南大在线测试平台',
  pwa: false,
  logo: '/01.png',
  iconfontUrl: '',
};
export default Settings;
